.. include:: ../release/0.16.0-notes.rst

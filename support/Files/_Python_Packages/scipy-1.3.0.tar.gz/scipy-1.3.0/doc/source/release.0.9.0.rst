.. include:: ../release/0.9.0-notes.rst

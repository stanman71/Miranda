.. _optimize.minimize-slsqp:

minimize(method='SLSQP')
---------------------------------------

.. scipy-optimize:function:: scipy.optimize.minimize
   :impl: scipy.optimize.slsqp._minimize_slsqp
   :method: SLSQP

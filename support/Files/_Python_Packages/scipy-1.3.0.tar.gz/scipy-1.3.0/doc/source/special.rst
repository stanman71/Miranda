.. automodule:: scipy.special
   :no-members:
   :no-inherited-members:
   :no-special-members:

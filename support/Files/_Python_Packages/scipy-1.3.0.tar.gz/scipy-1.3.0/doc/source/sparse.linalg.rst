.. automodule:: scipy.sparse.linalg
   :no-members:
   :no-inherited-members:
   :no-special-members:

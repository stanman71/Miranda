.. _optimize.root_scalar-halley:

root_scalar(method='halley')
----------------------------

.. scipy-optimize:function:: scipy.optimize.root_scalar
   :impl: scipy.optimize._root_scalar._root_scalar_halley_doc
   :method: halley


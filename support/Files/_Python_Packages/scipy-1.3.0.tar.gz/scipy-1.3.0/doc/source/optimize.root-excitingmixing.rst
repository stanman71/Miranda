.. _optimize.root-excitingmixing:

root(method='excitingmixing')
--------------------------------------------

.. scipy-optimize:function:: scipy.optimize.root
   :impl: scipy.optimize._root._root_excitingmixing_doc
   :method: excitingmixing

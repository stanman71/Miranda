.. automodule:: scipy.odr
   :no-members:
   :no-inherited-members:
   :no-special-members:

.. _classification_examples:

Classification
-----------------------

General examples about classification algorithms.

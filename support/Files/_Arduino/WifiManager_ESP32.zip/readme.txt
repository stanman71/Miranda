https://github.com/zhouhan0126/WIFIMANAGER-ESP32



C:\Program Files (x86)\Arduino\libraries

>>> Delete WifiManager for ESP8266

>>> insert and rename folder "WIFIMANAGER-ESP32-master" to "WifiManager"

>>> remove existing folder "Wifi"


-----
ESP32
-----

.\AppData\Local\Arduino15\packages\esp32\hardware\esp32\1.0.2\libraries\WebServer\src\HTTP_Method.h

>>> remove row "HTTP_HEAD = 0b00100000"
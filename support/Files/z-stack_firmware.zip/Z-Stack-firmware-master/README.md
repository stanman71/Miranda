# Z-Stack-firmware
This reposistory contains:
- Compiled Z-Stack firmwares (`.hex` files)
    - If you want to use these to flash to your CC253X (using the [Flash Programmer (not v2)](http://www.ti.com/tool/FLASH-PROGRAMMER) for example).
    - If you want to use these to flash to your CC2652R (using the [Flash Programmer v2](http://www.ti.com/tool/FLASH-PROGRAMMER) for example).
- Instructions on how to compile them

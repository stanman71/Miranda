# CC2530_CC2591 router firmware
Currently no compilation instructions are available for this firmware.

Credits for this firmware go to [ptvoinfo](https://github.com/ptvoinfo)
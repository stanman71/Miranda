//
//  AppDelegate.h
//  SnowboyTest
//
//  Created by Patrick Quinn on 16/02/2017.
//  Copyright © 2017 Kitt.ai. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>


@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end


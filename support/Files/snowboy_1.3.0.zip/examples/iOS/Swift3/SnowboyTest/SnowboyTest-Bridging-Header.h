//
//  SnowboyTest-Bridging-Header.h
//  SnowboyTest
//
//  Created by Bi, Sheng on 2/13/17.
//  Copyright © 2017 Bi, Sheng. All rights reserved.
//

#ifndef SnowboyTest_Bridging_Header_h
#define SnowboyTest_Bridging_Header_h

#import "SnowboyWrapper.h"

#endif /* SnowboyTest_Bridging_Header_h */

# See http://www.python.org/dev/peps/pep-0386/
# Examples:
# * 1.0.dev
# * 1.0a2
# * 1.0b2
# * 1.0

__version__ = '0.1.1'
__releasedate__ = ''
